sudo docker stop banco
sudo docker stop app
sudo docker rm banco
sudo docker rm app
sudo docker rmi -f matheus/app
sudo docker rmi -f matheus/bd
sudo docker build -t matheus/bd ./postgres
cd dac-jsf && mvn clean package && cd ..
sudo docker build -t matheus/app .
sudo docker run -p 5433:5432 -d --name banco matheus/bd
sudo docker run -p 8081:8080 -d --name app --link banco:host-banco matheus/app
